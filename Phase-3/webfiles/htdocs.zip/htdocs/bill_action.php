<?php
    error_reporting(0);
    $name = $_GET["bill"];
    $rest =$_GET["Restaurant"];
    $billNumber=$_GET["billNumber"];
    $total=$_GET["TA"];
    $tax=$_GET["TX"];
    $billD=$_GET["BD"];
    $CI=$_GET["CI"];
    $db_connection = pg_connect("host=127.0.0.1 dbname=db1 user=postgres password=pass");
    
    if (!isset($_GET["Restaurant"])) {
        $result = pg_query($db_connection, "SELECT * FROM BILL where bill_no = "."'".$name."'");
    /*  
     if(!sizeof(pg_fetch_array($result)))
     { 
                echo "Dish not present";
     }
     */

    echo "<table>";
    // echo "<tr><td>res_name</td><td>bill_no</td><td>total_amount</td><td>tax</td><td>order_details</td><td>cust_id</td></tr>";
    while ($row = pg_fetch_array($result)) {
            echo "<tr>";
            foreach ($row as $column) {
                echo "<td>$column</td>";
            }
            echo "</tr>";
        }    
    
    
    // no data passed by get
}else {
    $result = pg_query($db_connection,"INSERT INTO BILL (Res_Name,Bill_No,Total_Amount,Tax,Order_details,Cust_ID) VALUES ('$rest',$billNumber,$total,$tax,'$billD','$CI')");
    echo pg_last_error($db_connection);
    echo "added item";
    
}
    
  
   

?>