<?php
    error_reporting(0);
    $name = $_GET["dish"];
    $rest =$_GET["Restaurant"];
    $in=$_GET["Item_number"];
    $desc=$_GET["Description"];
    $quant=$_GET["Quantity"];
    $price=$_GET["Price"];
    $db_connection = pg_connect("host=127.0.0.1 dbname=db1 user=postgres password=pass");
    
    if (!isset($_GET["Description"])) {
        $result = pg_query($db_connection, "SELECT Description ,Res_Name FROM ITEM where Description = "."'".$name."'");
     /*  
     if(!sizeof(pg_fetch_array($result)))
     {
                echo "Dish not present";
     }
     */

         echo "<table>";
   // echo "<tr><td>res_name</td><td>bill_no</td><td>total_amount</td><td>tax</td><td>order_details</td><td>cust_id</td></tr>";
    while($row = pg_fetch_array($result))
        {
     echo "<tr>";
   foreach ($row as $column) {
      echo "<td>$column</td>";
    }
     echo "</tr>";
    }    
    
    
    // no data passed by get
}else {
    $result = pg_query($db_connection,"INSERT INTO ITEM(Res_Name,Item_Number,Description,Quantity,Price)VALUES('$rest','$in','$desc','$quant','$price')");
    echo pg_last_error($db_connection);
    echo "added item";
    
}
    
  
   

?>