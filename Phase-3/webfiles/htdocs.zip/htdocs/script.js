function func() {
	v1=document.getElementById('v1');
	v1.play();
	v1.currentTime=20;
	if (navigator.userAgent.subString("Chrome")) {
		v1.muted=true;
	}
	navigator.geolocation.getCurrentPosition(func1);
	setInterval(func1,10000);
	clearInterval(t1);
}

function func1(position) {
	position.coords.longitude
}